#include <bits/stdc++.h>
using namespace std;
int count_in(int arr[], int n) ;
int main() {
    int n;
    cout << "Size of array: ";
    cin >> n;
    int* arr1 = new int[n];
    for (int i = 0; i < n; i++) {cin >> arr1[i];}
    int size1 = sizeof(arr1) / sizeof(arr1[0]);
    int inv_insert = count_in(arr1, size1);
    cout << "Total Insertion Sort Inversions : " << inv_insert << endl;
    int result = (size1 * (size1 - 1)) / 2;
    cout << "Highest no. of inversions using Insertion Sort technique : " << result << endl;
    delete[] arr1;
    return 0;
}
int count_in(int arr[], int n) {
    int inv = 0;
    for (int i = 1; i < n; i++) {
        int k = 0;
        k= arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > k) {
            arr[j + 1] = arr[j];
            j--;
            inv++;
        }
        arr[j + 1] = k;
    }
    return inv;
}